# 项目维护指南

本文面向维护 `portrait-login` 的开发者与编码助手。使用说明、安装命令和配置字段见 [README.md](README.md)。修改前先阅读本文件及与任务有关的源码，以实际实现为准。

## 项目定位

- 模组名称：冒险者之门 · 角色立绘登录；ID：`portrait-login`；当前版本：`1.1.1`。
- 当前目标版本为 Foundry VTT **13.351**。接入工具会检查程序 `package.json` 中的 `name`、`release.generation` 和 `release.build`，拒绝其他版本。
- 这是直接运行的 JavaScript ES Modules 与 CSS 项目，没有 `package.json`、依赖安装流程、打包步骤或第三方测试框架；接入器回归测试使用 `node --test tests/world-scope.test.mjs`。
- 世界内配置界面和未登录时的主题是两个入口。`module.json` 只声明 `settings.mjs` 与 `settings.css`；登录页通过 `tools/install.mjs` 修改 Foundry 的 `templates/views/join.hbs` 接入。

## 文件职责

| 文件 | 职责 |
| --- | --- |
| `module.json` | 模组标识、兼容性、世界内入口、持久存储声明 |
| `scripts/model.mjs` | 默认数据、配置规范化、文本转义、资源 URL、图片显示逻辑 |
| `scripts/settings.mjs` | `ApplicationV2` 配置窗口、账户绑定、导入导出、GM 发布 |
| `scripts/login.mjs` | 配置加载、角色展示、原生账户联动、DOM 更新监听、回退 |
| `scripts/scene.mjs` | 登录页与全屏编辑器共用的场景、文本和布局渲染 |
| `styles/scene.css` | 共用布局、主题变量、角色卡与减少动画适配 |
| `styles/login.css` | 登录页全屏与禁用页面滚动、原生界面覆盖 |
| `styles/settings.css` | 世界内配置窗口样式 |
| `tools/install.mjs` | 模板接入、检查、备份与恢复，仅使用 Node.js 内置模块 |
| `config.json` | 可导入编辑器的示例配置，不自动用于登录页 |
| `storage/` | GM 发布的各世界配置；更新时保留 |
| `assets/` | 五角色示例合影、素材说明与生成提示 |
| `测试结果.json`、`使用说明.md` | 历史验证记录与使用说明；其中本机信息不是当前环境保证 |

## 修改前确认

1. 明确本次影响的是登录页、世界内设置、共享数据还是安装工具，阅读对应入口和共享模型。
2. 检查现有文件及用户改动；不要假定存在 Git 仓库、可运行的 Foundry 服务、历史演示世界或历史说明中的安装目录。
3. 对多步任务给出简短步骤与验证方式。常规且可逆的实现选择自行决定；只有会实质影响需求、目标或权限的缺失信息才需要澄清。
4. 限定改动范围，不顺带重排压缩样式、整体格式化、引入框架或修复无关问题。

## 必须保留的行为边界

### 原生登录

- 保留 Foundry 的表单提交、密码验证、会话、错误提示和跳转。角色卡只联动原生账户选择，不实现独立认证。
- 登录脚本依赖 `#join-game`、`#join-game-form`、`[name="userid"]`、`[name="password"]`、账户选项的 `disabled` 状态；升级兼容性时必须在目标版本实测这些约定。
- 角色卡导致账户变化时清空密码，不能选中已禁用的在线账户。维持手动选择账户、服务器管理入口和原始界面回退。
- `portraitLoginOff` 查询参数只要存在就跳过增强；常用写法为 `?portraitLoginOff=1`。
- 页面由 Foundry 动态渲染。保留重复挂载检查、监听器清理和异常时撤销主题的处理；新增观察行为应避免自身 DOM 更新触发循环。

### 配置与公开数据

- 配置入口统一调用 `normalize()`。配置结构发生变化时检查默认数据、编辑器读写、导入导出、发布和登录渲染，避免字段只在某一端生效。
- 默认示例同时存在于 `model.mjs` 的 `defaults` 和根目录 `config.json`。有意修改共同默认内容时同步两处。
- `layout.eyebrow/login/roster` 为共享布局；角色 `layout.name/tag/hero/description/detail` 为各角色独立布局。位置按视口百分比、缩放按倍数保存；编辑器与登录页复用 `scene.mjs` 和 `scene.css`。当前仅考虑桌面，join 页面固定一屏、不滚动。
- 登录页只读取 `storage/<世界ID>.json`，请求不使用缓存；缺失、无效或无法取得世界 ID 时保持原生页面，不自动套用示例。
- 编辑器从世界设置 `portrait-login.config` 读取；发布先通过 `FilePicker.implementation.uploadPersistent()` 写公开 JSON，再保存世界设置。不要把世界设置与公开文件视为自动同步或原子写入。
- `storage/` 是需要保留的用户数据。不要清空、覆盖其他世界文件，或把本机真实世界配置加入示例。
- 发布 JSON 包含账户 ID、图片路径、角色文案以及被隐藏的角色。`enabled: false` 只影响展示，不保护秘密信息。不要将密码、令牌或私密角色资料写入配置。
- 保持菜单限制与保存时的 GM 权限检查。导入已分配角色只提取当前实现需要的名字、图片与账户关联，不扩展为公开完整 Actor 数据。

### 文本、资源与样式

- 动态文字使用 `textContent`；插入配置窗口 HTML 的用户值使用共享 `escape()`。不要直接拼接未转义的用户内容。
- 图片地址通过 `assetURL()` 处理：`@/` 相对模组目录，其他相对路径基于 Foundry 服务根路径；允许 HTTP(S)，拒绝本机盘符与危险协议。保持反向代理子路径下的 URL 解析方式。
- `strip` 为 `0–4` 时使用五等分示例图；自定义图片应设为 `null`。显式提供 `hero` 时大立绘不分栏；`position: 0` 是有效值。
- 保持 `.pl-*` 命名，登录样式尽量限制在 `body.pl-active` 下。不要让主题样式影响正常世界界面。
- 编辑器打开前会加载带版本标识的设置样式，以兼容世界页面残留的旧样式。修改这些样式时同步更新 `settings.mjs` 的样式 URL 和 `settings.css` 的场景导入版本；用原生 `ApplicationV2` 检查新脚本与旧样式共存时的布局，不能只验证独立预览或 join 页面。
- 修改交互或布局时保留角色按钮的可访问名称、`aria-pressed`、状态播报、键盘左右切换、可见焦点与减少动画支持。
- 界面文案使用简明中文，说明用户可执行的操作或当前状态；不要把调试过程和实现细节放进产品文案。

### 安装与恢复

- 保留对 13.351 的严格检查；单独放宽 `module.json` 不能证明支持新版本。
- 保留 `portrait-login:v1:start/end` 标记、首次备份、重复安装不重复注入、模板结构检查和备份冲突保护。
- 恢复时只移除本主题接入，保留其他模板改动；不要无条件拿备份覆盖现有模板。
- 接入器修改登录模板及 `dist/server/views/join.mjs`，仅当前世界 core.moduleConfiguration 明确启用模组时注入资源；未登录客户端没有此设置，不得使用 game.modules 猜测。卸载需同时恢复两处接入。
- 未获对应操作授权时，不修改工作区外的真实 Foundry 程序或重启服务。测试安装器优先使用临时目录内的仿真模板，不能把仿真结果当成真实登录验证。

## 验证与交付

按改动范围选择验证，不为纯文档或微小样式修改建立额外测试框架。

语法检查（在项目根目录执行）：

```sh
node --check scripts/model.mjs
node --check scripts/scene.mjs
node --check scripts/login.mjs
node --check scripts/settings.mjs
node --check tools/install.mjs
```

| 改动范围 | 重点验证 |
| --- | --- |
| 文档 | 文件链接、命令、字段和默认值与源码一致；区分历史记录与本次验证 |
| 共享模型 | 默认配置、空列表、字段边界、`position: 0`、分栏、自定义图、URL 与文本处理 |
| 登录交互或样式 | 真实 13.351 下的 GM/玩家登录、错误密码、在线账户、切换账户、管理员入口、回退；桌面固定一屏、无页面滚动、键盘操作 |
| 配置窗口 | 全屏、八类元素拖动与缩放、双击文字编辑、布局持久化、增删排序、隐藏、账户绑定、图片浏览、导入导出、发布后刷新、不同世界配置隔离 |
| 安装器 | 临时模板下的版本拒绝、备份、重复安装、恢复、保留外部改动、备份冲突与不完整标记 |

`测试结果.json` 是已有测试结果摘要，没有可直接运行的测试用例。修改后仅报告实际执行的检查；未启动真实 Foundry 时，明确登录、发布和视觉效果尚未复验。交付说明包含修改内容、验证结果和未验证部分。

## 1.1.0 布局约定

笔记本内文字及顶部标语固定排版，不应用旧独立位置；保持双击编辑。初始选择为空，关闭资料页不清空账户。默认背景来自 background 或原生背景容器；idleHero 留空隐藏，idleHeroLayout 独立保存。切换动画取消前一动画并遵循减少动态效果。新增样式包括 doodle.css 与 notebook.css。

## Windows 双击入口
根目录两个 cmd 调用 tools/setup-windows.ps1；后者必须使用 UTF-8 BOM 以兼容 Windows PowerShell 5.1。借用 Foundry Electron 的 Node 模式，运行后检查文件状态，保留底层 install.mjs 的全部保护。不在浏览器内尝试写程序文件。
